// charts.js — лёгкие SVG-графики без библиотек. Данные всегда реальные (из базы).
const PALETTE = ['#4f6ef7', '#16a34a', '#d97706', '#7c3aed', '#dc2626', '#0891b2', '#db2777', '#65a30d', '#6b7280'];

const svgEl = (w, h) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', `0 0 ${w} ${h}`);
  s.classList.add('chart-svg');
  return s;
};
const esc = s => String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));

/** Горизонтальные полосы: data = [{label, value}] */
export function barChart(data, { color = PALETTE[0] } = {}) {
  const rows = data.filter(d => d.value > 0);
  if (!rows.length) return emptyNote();
  const max = Math.max(...rows.map(d => d.value));
  const rowH = 30, w = 560, labelW = 200;
  const svg = svgEl(w, rows.length * rowH + 6);
  let y = 4;
  for (const [i, d] of rows.entries()) {
    const bw = Math.max(3, (d.value / max) * (w - labelW - 50));
    svg.insertAdjacentHTML('beforeend', `
      <text x="${labelW - 10}" y="${y + 15}" text-anchor="end" font-size="12" fill="var(--text-2)">${esc(truncate(d.label, 26))}</text>
      <rect x="${labelW}" y="${y + 3}" width="${bw}" height="17" rx="5" fill="${d.color || color}" opacity="0.9"/>
      <text x="${labelW + bw + 8}" y="${y + 16}" font-size="12.5" font-weight="650" fill="var(--text)">${d.value}</text>`);
    y += rowH;
  }
  return svg;
}

/** Кольцевая диаграмма: data = [{label, value, color?}], возвращает {svg, legend} */
export function donutChart(data) {
  const rows = data.filter(d => d.value > 0);
  if (!rows.length) return { el: emptyNote() };
  const total = rows.reduce((a, d) => a + d.value, 0);
  const cx = 90, cy = 90, r = 66, sw = 26;
  const svg = svgEl(180, 180);
  let angle = -Math.PI / 2;
  rows.forEach((d, i) => {
    const frac = d.value / total;
    const a2 = angle + frac * 2 * Math.PI;
    const large = frac > 0.5 ? 1 : 0;
    const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
    const x2 = cx + r * Math.cos(a2 - 0.012), y2 = cy + r * Math.sin(a2 - 0.012);
    const color = d.color || PALETTE[i % PALETTE.length];
    if (frac >= 0.999) {
      svg.insertAdjacentHTML('beforeend', `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="${sw}"/>`);
    } else {
      svg.insertAdjacentHTML('beforeend',
        `<path d="M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="butt"/>`);
    }
    d._color = color;
    angle = a2;
  });
  svg.insertAdjacentHTML('beforeend',
    `<text x="${cx}" y="${cy - 2}" text-anchor="middle" font-size="26" font-weight="750" fill="var(--text)">${total}</text>
     <text x="${cx}" y="${cy + 18}" text-anchor="middle" font-size="11" fill="var(--text-3)">всего</text>`);
  const legend = document.createElement('div');
  legend.className = 'legend';
  for (const d of rows) {
    legend.insertAdjacentHTML('beforeend',
      `<span><i style="background:${d._color}"></i>${esc(d.label)} — ${d.value}</span>`);
  }
  const wrap = document.createElement('div');
  wrap.style.cssText = 'display:flex;gap:18px;align-items:center;flex-wrap:wrap';
  const svgBox = document.createElement('div');
  svgBox.style.cssText = 'width:150px;flex-shrink:0';
  svgBox.appendChild(svg);
  wrap.appendChild(svgBox);
  wrap.appendChild(legend);
  return { el: wrap };
}

/** Линия динамики: data = [{label, value}] (по дням/неделям) */
export function lineChart(data) {
  if (!data.length || data.every(d => !d.value)) return emptyNote();
  const w = 560, h = 170, padL = 30, padB = 26, padT = 12;
  const max = Math.max(...data.map(d => d.value), 1);
  const stepX = (w - padL - 10) / Math.max(data.length - 1, 1);
  const pts = data.map((d, i) => [padL + i * stepX, padT + (1 - d.value / max) * (h - padT - padB)]);
  const path = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = path + ` L ${pts[pts.length - 1][0].toFixed(1)} ${h - padB} L ${padL} ${h - padB} Z`;
  const svg = svgEl(w, h);
  svg.insertAdjacentHTML('beforeend', `
    <defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#4f6ef7" stop-opacity="0.25"/>
      <stop offset="1" stop-color="#4f6ef7" stop-opacity="0"/></linearGradient></defs>
    <line x1="${padL}" y1="${h - padB}" x2="${w - 8}" y2="${h - padB}" stroke="var(--border)" />
    <path d="${area}" fill="url(#lg)"/>
    <path d="${path}" fill="none" stroke="#4f6ef7" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`);
  for (const [i, p] of pts.entries()) {
    if (data[i].value > 0) {
      svg.insertAdjacentHTML('beforeend', `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="#4f6ef7"/>
        <text x="${p[0]}" y="${p[1] - 9}" text-anchor="middle" font-size="10.5" font-weight="600" fill="var(--text-2)">${data[i].value}</text>`);
    }
  }
  const every = Math.ceil(data.length / 8);
  data.forEach((d, i) => {
    if (i % every === 0 || i === data.length - 1) {
      svg.insertAdjacentHTML('beforeend',
        `<text x="${pts[i][0]}" y="${h - 8}" text-anchor="middle" font-size="10" fill="var(--text-3)">${esc(d.label)}</text>`);
    }
  });
  return svg;
}

function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

function emptyNote() {
  const d = document.createElement('div');
  d.className = 'dim';
  d.style.cssText = 'padding:26px;text-align:center';
  d.textContent = 'Пока нет данных для графика';
  return d;
}

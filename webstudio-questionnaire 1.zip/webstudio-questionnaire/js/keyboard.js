// keyboard.js — удобство экранной клавиатуры на телефоне:
//  • панель «Готово» над клавиатурой (прячет клавиатуру);
//  • Enter в однострочном поле закрывает клавиатуру;
//  • тап по пустому месту закрывает клавиатуру;
//  • поле в фокусе прокручивается в видимую зону.

const TEXTLIKE = new Set(['text', 'search', 'tel', 'email', 'url', 'number', 'password', 'date', '']);

function isTextField(el) {
  if (!el || !el.tagName) return false;
  if (el.tagName === 'TEXTAREA') return true;
  return el.tagName === 'INPUT' && TEXTLIKE.has((el.getAttribute('type') || '').toLowerCase());
}

export function initKeyboardHelper() {
  const touch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
  if (!touch) return;

  const bar = document.createElement('div');
  bar.className = 'kbd-bar no-print';
  bar.innerHTML = '<button type="button" class="btn btn-primary btn-sm" id="kbd-done">Готово ⌄</button>';
  document.body.appendChild(bar);
  const vv = window.visualViewport;

  const place = () => {
    const bottom = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
    bar.style.bottom = bottom + 'px';
  };
  const hide = () => bar.classList.remove('show');
  const show = () => { place(); bar.classList.add('show'); };

  if (vv) { vv.addEventListener('resize', place); vv.addEventListener('scroll', place); }

  // не отбираем фокус у поля при нажатии на кнопку
  bar.addEventListener('mousedown', e => e.preventDefault());
  bar.querySelector('#kbd-done').addEventListener('click', () => {
    document.activeElement?.blur();
    hide();
  });

  document.addEventListener('focusin', e => {
    if (!isTextField(e.target)) return;
    show();
    // дать клавиатуре открыться, затем показать поле
    setTimeout(() => {
      place();
      try { e.target.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (_) {}
    }, 320);
  });
  document.addEventListener('focusout', () => {
    setTimeout(() => { if (!isTextField(document.activeElement)) hide(); }, 80);
  });

  // Enter в однострочном поле = закрыть клавиатуру
  document.addEventListener('keydown', e => {
    const t = e.target;
    if (e.key === 'Enter' && t.tagName === 'INPUT' && isTextField(t)) {
      if (t.dataset.enterSubmit) return; // поля, где Enter имеет свой смысл (вход админа)
      e.preventDefault();
      t.blur();
      hide();
    }
  });

  // Тап по пустому месту — закрыть клавиатуру
  document.addEventListener('click', e => {
    if (!isTextField(document.activeElement)) return;
    if (e.target.closest('input, textarea, select, button, a, label, .chip, .typecard, .seg, .kbd-bar, .modal')) return;
    document.activeElement.blur();
    hide();
  });
}

// survey.js — клиентская часть: главная, пошаговый мастер, финальный просмотр.
import { SITE_TYPES, SCALES, DEFAULT_CONSENT_TEXT } from './schema.js';
import {
  visibleStages, visibleQuestions, validateStage, progress, newQuestionnaire,
  logHistory, displayValue, fullReportText,
} from './logic.js';
import * as db from './db.js';
import { esc, uuid, nowISO, fmtDate, fmtSize, debounce, toast, confirmDialog, navTo, navBack, copyText } from './util.js';
import { themeButton } from './app.js';

const ALLOWED_EXT = ['jpg', 'jpeg', 'png', 'webp', 'pdf', 'docx', 'xlsx', 'txt'];
const MAX_FILE_MB = 15;
const MAX_FILES_PER_Q = 20;

// ───────────────────────── Главная ─────────────────────────
export async function renderHome(app) {
  const all = await db.getAllQuestionnaires();
  const drafts = all
    .filter(q => q.status === 'draft' || q.status === 'progress')
    .sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''));

  app.innerHTML = `
    <div class="topbar">
      <div class="brand"><div class="logo">W</div> WebStudio Questionnaire</div>
      <div class="nav-actions"></div>
    </div>
    <div class="hero">
      <h1>Анкета для разработки сайта</h1>
      <p>Ответьте на вопросы о вашем бизнесе и будущем сайте — это займёт 15–25 минут.
         Ответы сохраняются автоматически, можно прерваться и продолжить позже.</p>
      <div class="hero-actions">
        <button class="btn btn-primary" id="btn-new" style="padding:13px 28px;font-size:15.5px">Заполнить анкету</button>
      </div>
    </div>
    ${drafts.length ? `
      <div class="card" style="margin-top:8px">
        <h3 style="margin-bottom:12px">Незавершённые анкеты</h3>
        <div class="qlist" id="drafts"></div>
      </div>` : ''}
    <p style="text-align:center;margin-top:28px"><a class="dim" href="#/admin">Вход для администратора</a></p>
  `;
  app.querySelector('.nav-actions').appendChild(themeButton());
  app.querySelector('#btn-new').onclick = async () => {
    const q = newQuestionnaire();
    logHistory(q, 'Анкета создана');
    await db.putQuestionnaire(q);
    location.hash = '#/survey/' + q.id;
  };
  if (drafts.length) {
    const host = app.querySelector('#drafts');
    for (const q of drafts) {
      const p = progress(q);
      const row = document.createElement('div');
      row.className = 'card qrow';
      row.innerHTML = `
        <div class="qmain">
          <div class="qtitle">${esc(q.answers?.company_name || 'Анкета без названия')}</div>
          <div class="qsub">Изменена ${fmtDate(q.updated_at)} · заполнено ${p.percent}%</div>
        </div>
        <span class="badge badge-blue">Продолжить</span>
        <button class="btn btn-ghost btn-icon btn-sm row-del" title="Удалить черновик" aria-label="Удалить черновик">🗑</button>`;
      row.querySelector('.row-del').onclick = async (e) => {
        e.stopPropagation();
        const ok = await confirmDialog('Удалить черновик?',
          `Незавершённая анкета «${q.answers?.company_name || 'без названия'}» и её файлы будут удалены безвозвратно.`,
          { okLabel: 'Удалить', danger: true });
        if (!ok) return;
        await db.deleteQuestionnaire(q.id);
        toast('Черновик удалён', 'info');
        renderHome(app);
      };
      row.onclick = () => location.hash = '#/survey/' + q.id;
      host.appendChild(row);
    }
  }
}

// ───────────────────────── Мастер опроса ─────────────────────────
export async function renderSurvey(app, idAndStage) {
  const [id, stageParam] = (idAndStage || '').split('?s=');
  const q = await db.getQuestionnaire(id);
  if (!q) {
    toast('Анкета не найдена', 'error');
    location.hash = '#/';
    return;
  }
  if (stageParam != null) q.stage_index = parseInt(stageParam, 10) || 0;

  const save = async (silent = true) => {
    q.updated_at = nowISO();
    if (q.status === 'draft' && Object.keys(q.answers).length > 1) q.status = 'progress';
    const stateEl = () => document.getElementById('save-state');
    try {
      await db.putQuestionnaire(q);
      if (stateEl()) stateEl().textContent = '✓ Сохранено в ' + new Date().toTimeString().slice(0, 5);
    } catch (err) {
      if (stateEl()) stateEl().textContent = '⚠ Не сохранено';
      toast('Не удалось сохранить: ' + err.message, 'error', 6000);
      throw err;
    }
    if (!silent) toast('Сохранено', 'success', 1500);
  };
  const autoSave = debounce(() => save().catch(() => {}), 500);

  // Вперёд — новая запись истории; назад — настоящий history.back(),
  // поэтому системный «назад»/свайп на iPhone ведёт на предыдущий этап.
  const stageHash = i => `#/survey/${q.id}?s=${i}`;
  const goStage = async (i) => {
    const from = q.stage_index;
    q.stage_index = i;
    await save();
    if (i === from - 1) navBack(i, stageHash(i), from);
    else navTo(stageHash(i), from);
  };

  let stages = visibleStages(q);
  if (q.stage_index >= stages.length) q.stage_index = stages.length - 1;

  const render = () => {
    stages = visibleStages(q);
    if (q.stage_index >= stages.length) q.stage_index = stages.length - 1;
    const stage = stages[q.stage_index];
    const p = progress(q);
    const isLast = q.stage_index === stages.length - 1;

    app.innerHTML = `
      <div class="topbar no-print">
        <div class="topbar-left">
          <button class="btn btn-ghost btn-icon" id="btn-top-back" aria-label="Назад" title="Назад">←</button>
          <div class="brand"><div class="logo">W</div><span class="brand-name">Анкета сайта</span></div>
        </div>
        <div class="nav-actions">
          <button class="btn btn-ghost btn-sm" id="btn-exit">Сохранить и выйти</button>
        </div>
      </div>
      <div class="progress-wrap no-print">
        <div class="pbar"><div style="width:${p.percent}%"></div></div>
        <div class="steps" id="steps"></div>
        <div class="savestate" id="save-state">Ответы сохраняются автоматически</div>
      </div>
      <div class="card" style="margin-top:10px">
        <h2>${stage.icon} ${esc(stage.title)}</h2>
        <p class="muted" style="margin:6px 0 20px">${esc(stage.desc || '')}</p>
        <div id="questions"></div>
      </div>
      <div class="wiz-nav">
        ${q.stage_index > 0 ? '<button class="btn btn-ghost" id="btn-back">← Назад</button>' : ''}
        <button class="btn btn-primary" id="btn-next">${isLast ? 'К просмотру анкеты' : 'Продолжить →'}</button>
      </div>`;

    app.querySelector('.nav-actions').prepend(themeButton());

    // Шаги
    const stepsHost = app.querySelector('#steps');
    stages.forEach((st, i) => {
      const pill = document.createElement('span');
      pill.className = 'step-pill' + (i === q.stage_index ? ' on' : i < q.stage_index ? ' done' : '');
      pill.textContent = `${i + 1}. ${st.title}`;
      if (i <= q.stage_index) pill.onclick = () => goStage(i);
      stepsHost.appendChild(pill);
    });
    stepsHost.querySelector('.on')?.scrollIntoView({ inline: 'center', block: 'nearest' });

    // Вопросы
    const qHost = app.querySelector('#questions');
    renderQuestions(qHost, stage, q, { autoSave, rerender: render });

    // Навигация
    app.querySelector('#btn-exit').onclick = async () => { await save(false); location.hash = '#/'; };
    const back = app.querySelector('#btn-back');
    if (back) back.onclick = () => goStage(q.stage_index - 1);
    app.querySelector('#btn-top-back').onclick = async () => {
      if (q.stage_index > 0) return goStage(q.stage_index - 1);
      await save(); location.hash = '#/';
    };
    app.querySelector('#btn-next').onclick = async () => {
      const errors = validateStage(stage, q);
      markErrors(qHost, errors);
      if (errors.length) {
        toast('Заполните обязательные поля', 'error');
        qHost.querySelector('.field.error')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      if (isLast) { await save(); navTo('#/review/' + q.id, q.stage_index); }
      else await goStage(q.stage_index + 1);
    };
  };

  render();
}

function markErrors(host, errors) {
  host.querySelectorAll('.field.error').forEach(f => f.classList.remove('error'));
  host.querySelectorAll('.err-msg').forEach(e => e.remove());
  for (const err of errors) {
    const f = host.querySelector(`[data-qid="${err.id}"]`);
    if (f) {
      f.classList.add('error');
      const m = document.createElement('div');
      m.className = 'err-msg';
      m.textContent = err.msg;
      f.appendChild(m);
    }
  }
}

// ───────────────────────── Рендер вопросов ─────────────────────────
function renderQuestions(host, stage, q, ctx) {
  host.innerHTML = '';
  const qs = visibleQuestions(stage, q);
  for (const question of qs) host.appendChild(renderQuestion(question, q, ctx, stage));
}

function fieldWrap(question) {
  const f = document.createElement('div');
  f.className = 'field';
  f.dataset.qid = question.id;
  if (question.type !== 'consent') {
    f.innerHTML = `<label class="q-label">${esc(question.label)}${question.required ? '<span class="req">*</span>' : ''}</label>`;
    if (question.hint) f.insertAdjacentHTML('beforeend', `<div class="hint">${esc(question.hint)}</div>`);
  }
  return f;
}

function renderQuestion(question, q, ctx, stage) {
  const a = q.answers;
  const f = fieldWrap(question);
  const changed = (needRerender = false) => {
    ctx.autoSave();
    if (needRerender) ctx.rerender();
  };
  switch (question.type) {
    case 'text': {
      const inp = document.createElement('input');
      inp.className = 'input';
      inp.type = 'text';
      inp.enterKeyHint = 'done';
      if (question.inputmode) inp.inputMode = question.inputmode;
      inp.value = a[question.id] || '';
      inp.oninput = () => { a[question.id] = inp.value; changed(); };
      f.appendChild(inp);
      break;
    }
    case 'textarea': {
      const inp = document.createElement('textarea');
      inp.className = 'input';
      inp.value = a[question.id] || '';
      inp.oninput = () => { a[question.id] = inp.value; changed(); autoGrow(inp); };
      f.appendChild(inp);
      requestAnimationFrame(() => autoGrow(inp));
      break;
    }
    case 'select': {
      const sel = document.createElement('select');
      sel.className = 'input';
      const opts = resolveOptions(question, q);
      sel.innerHTML = '<option value="">— Не выбрано —</option>' +
        opts.map(o => `<option value="${esc(o.id)}">${esc(o.label)}</option>`).join('') +
        (question.other ? '<option value="__other__">Другое…</option>' : '');
      sel.value = a[question.id] || '';
      const otherInp = document.createElement('input');
      otherInp.className = 'input';
      otherInp.placeholder = 'Уточните…';
      otherInp.style.marginTop = '8px';
      otherInp.value = a[question.id + '__other'] || '';
      otherInp.hidden = sel.value !== '__other__';
      otherInp.oninput = () => { a[question.id + '__other'] = otherInp.value; changed(); };
      sel.onchange = () => {
        a[question.id] = sel.value || undefined;
        if (!sel.value) delete a[question.id];
        otherInp.hidden = sel.value !== '__other__';
        changed(SCHEMA_DEPENDENTS.has(question.id));
      };
      f.appendChild(sel);
      f.appendChild(otherInp);
      break;
    }
    case 'multi': {
      const wrap = document.createElement('div');
      wrap.className = 'chips';
      const opts = resolveOptions(question, q);
      const cur = () => a[question.id] || [];
      const make = (id, label) => {
        const lbl = document.createElement('label');
        lbl.className = 'chip' + (cur().includes(id) ? ' on' : '');
        lbl.innerHTML = `<input type="checkbox"> ${esc(label)}`;
        lbl.querySelector('input').checked = cur().includes(id);
        lbl.onclick = (e) => {
          e.preventDefault();
          const arr = new Set(cur());
          arr.has(id) ? arr.delete(id) : arr.add(id);
          a[question.id] = [...arr];
          if (!a[question.id].length) delete a[question.id];
          lbl.classList.toggle('on');
          otherInp.hidden = !(a[question.id] || []).includes('__other__');
          changed(SCHEMA_DEPENDENTS.has(question.id));
        };
        return lbl;
      };
      for (const o of opts) wrap.appendChild(make(o.id, o.label));
      if (question.other) wrap.appendChild(make('__other__', 'Другое…'));
      const otherInp = document.createElement('input');
      otherInp.className = 'input';
      otherInp.placeholder = 'Уточните…';
      otherInp.style.marginTop = '10px';
      otherInp.value = a[question.id + '__other'] || '';
      otherInp.hidden = !cur().includes('__other__');
      otherInp.oninput = () => { a[question.id + '__other'] = otherInp.value; changed(); };
      f.appendChild(wrap);
      f.appendChild(otherInp);
      break;
    }
    case 'typecards': {
      const grid = document.createElement('div');
      grid.className = 'typegrid';
      for (const t of SITE_TYPES) {
        const c = document.createElement('div');
        c.className = 'typecard' + (a.site_type === t.id ? ' on' : '');
        c.innerHTML = `<span class="ic">${t.icon}</span><span class="tl">${esc(t.label)}</span>`;
        c.onclick = () => {
          a.site_type = t.id;
          // убрать дубли из дополнительных направлений
          if (Array.isArray(a.site_type_extra)) {
            a.site_type_extra = a.site_type_extra.filter(x => x !== t.id);
            if (!a.site_type_extra.length) delete a.site_type_extra;
          }
          changed(true);
        };
        grid.appendChild(c);
      }
      f.appendChild(grid);
      break;
    }
    case 'matrix': {
      const scale = SCALES[question.scale || 'P'];
      const m = document.createElement('div');
      m.className = 'matrix';
      const val = a[question.id] || {};
      for (const row of question.rows) {
        const r = document.createElement('div');
        r.className = 'mrow';
        const lbl = document.createElement('div');
        lbl.className = 'mlabel';
        lbl.textContent = row.label;
        const seg = document.createElement('div');
        seg.className = 'seg';
        for (const s of scale) {
          const b = document.createElement('button');
          b.type = 'button';
          b.dataset.v = s.id;
          b.textContent = (question.scaleLabels && question.scaleLabels[s.id]) || s.label;
          if (val[row.id] === s.id) b.classList.add('on');
          b.onclick = () => {
            const cur = a[question.id] || (a[question.id] = {});
            if (cur[row.id] === s.id) { delete cur[row.id]; b.classList.remove('on'); }
            else {
              cur[row.id] = s.id;
              seg.querySelectorAll('button').forEach(x => x.classList.remove('on'));
              b.classList.add('on');
            }
            if (!Object.keys(a[question.id]).length) delete a[question.id];
            changed(SCHEMA_DEPENDENTS.has(question.id));
          };
          seg.appendChild(b);
        }
        r.appendChild(lbl);
        r.appendChild(seg);
        m.appendChild(r);
      }
      f.appendChild(m);
      break;
    }
    case 'files': {
      renderFileInput(f, question, q, ctx);
      break;
    }
    case 'consent': {
      const box = document.createElement('div');
      box.className = 'consent-box';
      const render = async () => {
        const custom = await db.getSetting('consent_text');
        box.innerHTML = `
          <div>${esc(custom || DEFAULT_CONSENT_TEXT)}</div>
          <label><input type="checkbox" ${a.consent === true ? 'checked' : ''}>
            Я согласен(на) с обработкой указанных данных<span class="req">*</span></label>`;
        box.querySelector('input').onchange = (e) => {
          a.consent = e.target.checked ? true : undefined;
          if (!a.consent) delete a.consent;
          ctx.autoSave();
        };
      };
      render();
      f.appendChild(box);
      break;
    }
  }
  if (question.example) f.insertAdjacentHTML('beforeend', `<div class="example">Пример: ${esc(question.example)}</div>`);
  return f;
}

function autoGrow(ta) {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight + 2, 400) + 'px';
}

function resolveOptions(question, q) {
  if (question.options === 'SITE_TYPES_EXTRA') {
    return SITE_TYPES.filter(t => t.id !== q.answers.site_type).map(t => ({ id: t.id, label: t.label }));
  }
  return question.options || [];
}

// Вопросы, от которых зависит видимость других (кэш по схеме)
import { STAGES as _ST } from './schema.js';
const SCHEMA_DEPENDENTS = (() => {
  const deps = new Set(['site_type', 'site_type_extra']);
  const walk = c => {
    if (!c) return;
    if (c.q) deps.add(c.q);
    if (c.matrix) deps.add(c.matrix);
    (c.all || []).forEach(walk);
    (c.any || []).forEach(walk);
  };
  for (const st of _ST) {
    walk(st.showIf);
    for (const question of st.questions) walk(question.showIf);
  }
  return deps;
})();

// ───────────────────────── Файлы ─────────────────────────
function sanitizeName(name) {
  const base = name.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 120);
  return base || 'file';
}

function renderFileInput(f, question, q, ctx) {
  const zone = document.createElement('div');
  zone.className = 'dropzone';
  zone.innerHTML = `📎 Нажмите, чтобы выбрать файлы<br><span class="dim">JPG, PNG, WEBP, PDF, DOCX, XLSX, TXT · до ${MAX_FILE_MB} МБ</span>`;
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.multiple = true;
  inp.accept = '.jpg,.jpeg,.png,.webp,.pdf,.docx,.xlsx,.txt,image/*';
  inp.hidden = true;
  const list = document.createElement('div');
  list.className = 'filelist';

  const refresh = () => {
    list.innerHTML = '';
    for (const ref of (q.fileRefs || []).filter(r => r.qid === question.id)) {
      const item = document.createElement('div');
      item.className = 'fileitem';
      item.innerHTML = `<span>📄</span><span class="fname">${esc(ref.name)}</span>
        <span class="dim">${fmtSize(ref.size)}</span>
        <button class="fdel" title="Удалить">✕</button>`;
      item.querySelector('.fdel').onclick = async () => {
        if (!(await confirmDialog('Удалить файл?', `Файл «${ref.name}» будет удалён из анкеты.`, { okLabel: 'Удалить', danger: true }))) return;
        await db.deleteFile(ref.id);
        q.fileRefs = q.fileRefs.filter(r => r.id !== ref.id);
        await db.putQuestionnaire(q);
        refresh();
        toast('Файл удалён', 'info');
      };
      list.appendChild(item);
    }
  };

  const addFiles = async (files) => {
    const current = (q.fileRefs || []).filter(r => r.qid === question.id).length;
    let added = 0;
    for (const file of files) {
      if (current + added >= MAX_FILES_PER_Q) { toast(`Не более ${MAX_FILES_PER_Q} файлов на вопрос`, 'error'); break; }
      const ext = (file.name.split('.').pop() || '').toLowerCase();
      if (!ALLOWED_EXT.includes(ext)) { toast(`«${file.name}»: формат .${ext} не поддерживается`, 'error', 4500); continue; }
      if (file.size > MAX_FILE_MB * 1024 * 1024) { toast(`«${file.name}»: больше ${MAX_FILE_MB} МБ`, 'error', 4500); continue; }
      const ref = { id: uuid(), qid: question.id, name: sanitizeName(file.name), type: file.type || 'application/octet-stream', size: file.size };
      try {
        await db.putFile({ ...ref, blob: file });
        q.fileRefs = q.fileRefs || [];
        q.fileRefs.push(ref);
        added++;
      } catch (err) {
        toast('Не удалось сохранить файл: ' + err.message, 'error', 5000);
      }
    }
    if (added) {
      q.updated_at = nowISO();
      await db.putQuestionnaire(q);
      toast(added === 1 ? 'Файл добавлен' : `Добавлено файлов: ${added}`, 'success');
      refresh();
    }
  };

  zone.onclick = () => inp.click();
  zone.ondragover = e => { e.preventDefault(); zone.classList.add('drag'); };
  zone.ondragleave = () => zone.classList.remove('drag');
  zone.ondrop = e => { e.preventDefault(); zone.classList.remove('drag'); addFiles(e.dataTransfer.files); };
  inp.onchange = () => { addFiles(inp.files); inp.value = ''; };

  f.appendChild(zone);
  f.appendChild(inp);
  f.appendChild(list);
  refresh();
}

// ───────────────────────── Финальный просмотр ─────────────────────────
export async function renderReview(app, id) {
  const q = await db.getQuestionnaire(id);
  if (!q) { location.hash = '#/'; return; }
  const stages = visibleStages(q);
  const p = progress(q);

  app.innerHTML = `
    <div class="topbar no-print">
      <div class="topbar-left">
        <button class="btn btn-ghost btn-icon" id="btn-top-back" aria-label="Назад" title="Назад">←</button>
        <div class="brand"><div class="logo">W</div><span class="brand-name">Проверка анкеты</span></div>
      </div>
      <div class="nav-actions"></div>
    </div>
    <div class="card">
      <h2>Проверьте ответы перед отправкой</h2>
      <p class="muted" style="margin:6px 0 4px">Заполнено ${p.answered} из ${p.total} вопросов (${p.percent}%).
        Нажмите «Изменить», чтобы вернуться к любому этапу.</p>
      <button class="btn btn-ghost btn-sm" id="btn-copy-all" style="margin-top:10px">📋 Скопировать весь итог</button>
    </div>
    <div id="review"></div>
    <div class="wiz-nav">
      <button class="btn btn-ghost" id="btn-back">← Вернуться</button>
      <button class="btn btn-primary" id="btn-submit">Отправить анкету ✓</button>
    </div>`;
  app.querySelector('.nav-actions').appendChild(themeButton());

  const host = app.querySelector('#review');
  stages.forEach((st, i) => {
    const block = document.createElement('div');
    block.className = 'card';
    block.style.marginTop = '12px';
    let rows = '';
    for (const question of visibleQuestions(st, q)) {
      const v = displayValue(question, q.answers[question.id], q);
      const text = v == null ? '<span class="dim">— не заполнено —</span>'
        : Array.isArray(v) ? esc(v.join('\n')) : esc(v);
      rows += `<div class="review-q"><div class="rq">${esc(question.label)}</div><div class="ra">${text}</div></div>`;
    }
    block.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px">
        <h3>${st.icon} ${esc(st.title)}</h3>
        <button class="btn btn-ghost btn-sm">Изменить</button>
      </div>${rows}`;
    block.querySelector('button').onclick = () => {
      location.hash = `#/survey/${q.id}?s=${i}`;
    };
    host.appendChild(block);
  });

  app.querySelector('#btn-copy-all').onclick = async () => {
    (await copyText(fullReportText(q)))
      ? toast('Весь итог скопирован — можно вставить в сообщение или документ', 'success', 3500)
      : toast('Не удалось скопировать автоматически', 'error');
  };
  const last = stages.length - 1;
  const toLast = () => navBack(last, `#/survey/${q.id}?s=${last}`, null);
  app.querySelector('#btn-back').onclick = toLast;
  app.querySelector('#btn-top-back').onclick = toLast;
  app.querySelector('#btn-submit').onclick = async () => {
    // финальная проверка всех обязательных полей
    for (let i = 0; i < stages.length; i++) {
      const errors = validateStage(stages[i], q);
      if (errors.length) {
        toast(`На этапе «${stages[i].title}» есть незаполненные обязательные поля`, 'error', 5000);
        location.hash = `#/survey/${q.id}?s=${i}`;
        return;
      }
    }
    q.status = 'completed';
    q.completed_at = nowISO();
    q.updated_at = q.completed_at;
    logHistory(q, 'Анкета завершена клиентом');
    await db.putQuestionnaire(q);
    location.hash = '#/done';
  };
}

export async function renderDone(app) {
  app.innerHTML = `
    <div class="hero" style="padding-top:80px">
      <div style="font-size:56px;margin-bottom:16px">🎉</div>
      <h1>Анкета отправлена!</h1>
      <p>Спасибо за подробные ответы. Мы изучим информацию и свяжемся с вами
         удобным для вас способом.</p>
      <div class="hero-actions"><a class="btn btn-ghost" href="#/">На главную</a></div>
    </div>`;
}

// db.js — слой хранения поверх IndexedDB.
// Единый адаптер для Windows (Chrome/Edge) и iPhone (Safari PWA).
// Архитектурно изолирован: при появлении серверного режима (SQLite)
// достаточно заменить реализацию этих функций, не трогая остальной код.

const DB_NAME = 'webstudio_questionnaire';
const DB_VERSION = 1;

let _db = null;

export function openDB() {
  if (_db) return Promise.resolve(_db);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('questionnaires')) {
        const s = db.createObjectStore('questionnaires', { keyPath: 'id' });
        s.createIndex('status', 'status');
        s.createIndex('updated_at', 'updated_at');
      }
      if (!db.objectStoreNames.contains('files')) {
        const f = db.createObjectStore('files', { keyPath: 'id' });
        f.createIndex('qid', 'qid');
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };
    req.onsuccess = () => { _db = req.result; resolve(_db); };
    req.onerror = () => reject(req.error || new Error('Не удалось открыть базу данных'));
  });
}

function tx(store, mode, fn) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    let result;
    try { result = fn(s); } catch (err) { reject(err); return; }
    t.oncomplete = () => resolve(result && 'result' in result ? result.result : result);
    t.onerror = () => reject(t.error || new Error('Ошибка записи в базу'));
    t.onabort = () => reject(t.error || new Error('Транзакция прервана'));
  }));
}

function reqToPromise(storeName, mode, make) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(storeName, mode);
    const r = make(t.objectStore(storeName));
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  }));
}

// ---- Анкеты ----
export const putQuestionnaire = q => tx('questionnaires', 'readwrite', s => s.put(q));
export const getQuestionnaire = id => reqToPromise('questionnaires', 'readonly', s => s.get(id));
export const getAllQuestionnaires = () => reqToPromise('questionnaires', 'readonly', s => s.getAll());
export const deleteQuestionnaire = async (id) => {
  const files = await getFilesByQ(id);
  for (const f of files) await deleteFile(f.id);
  return tx('questionnaires', 'readwrite', s => s.delete(id));
};

// ---- Файлы ----
export const putFile = f => tx('files', 'readwrite', s => s.put(f));
export const getFile = id => reqToPromise('files', 'readonly', s => s.get(id));
export const deleteFile = id => tx('files', 'readwrite', s => s.delete(id));
export const getFilesByQ = qid => reqToPromise('files', 'readonly', s => s.index('qid').getAll(qid));
export const getAllFiles = () => reqToPromise('files', 'readonly', s => s.getAll());

// ---- Настройки (админ, тема, текст согласия…) ----
export const getSetting = async (key) => {
  const r = await reqToPromise('settings', 'readonly', s => s.get(key));
  return r ? r.value : null;
};
export const setSetting = (key, value) => tx('settings', 'readwrite', s => s.put({ key, value }));

// ---- Запрос постоянного хранилища (важно для iOS: защита от очистки) ----
export async function requestPersistence() {
  try {
    if (navigator.storage?.persist) {
      const persisted = await navigator.storage.persisted();
      if (!persisted) await navigator.storage.persist();
    }
  } catch (_) { /* не критично */ }
}

// ---- Полная очистка (используется только при восстановлении из копии) ----
export async function clearAllData() {
  await tx('questionnaires', 'readwrite', s => s.clear());
  await tx('files', 'readwrite', s => s.clear());
}

# server.py — локальный сервер WebStudio Questionnaire (только стандартная библиотека Python).
# Запуск: python server.py  (или start.bat на Windows)
# Сервер отдаёт статические файлы приложения. Все данные хранятся в браузере (IndexedDB).
import http.server
import socketserver
import webbrowser
import os
import sys

PORT = 8750
os.chdir(os.path.dirname(os.path.abspath(__file__)))


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.html': 'text/html; charset=utf-8',
        '.webmanifest': 'application/manifest+json; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.svg': 'image/svg+xml',
    }

    def end_headers(self):
        # приложение обновляется мгновенно, без устаревшего кэша
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # не шумим в консоли и не пишем данные в логи


def main():
    port = PORT
    for attempt in range(10):
        try:
            with socketserver.TCPServer(('127.0.0.1', port), Handler) as httpd:
                url = f'http://localhost:{port}/'
                print('=' * 52)
                print('  WebStudio Questionnaire запущен')
                print(f'  Откройте в браузере: {url}')
                print('  Для остановки закройте это окно или нажмите Ctrl+C')
                print('=' * 52)
                try:
                    webbrowser.open(url)
                except Exception:
                    pass
                httpd.serve_forever()
                return
        except OSError:
            port += 1  # порт занят — пробуем следующий
    print('Не удалось найти свободный порт. Закройте другие копии приложения.')
    sys.exit(1)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nСервер остановлен.')

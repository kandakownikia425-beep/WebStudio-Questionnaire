@echo off
chcp 65001 >nul
echo Остановка WebStudio Questionnaire...
taskkill /fi "WINDOWTITLE eq WebStudio Questionnaire*" /t /f >nul 2>nul
echo Готово. Если сервер был запущен в другом окне — просто закройте то окно.
pause
